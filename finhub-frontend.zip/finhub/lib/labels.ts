import type { Alert, SignalSpec } from "./api";

const SOURCE_LABELS: Record<string, string> = {
  price: "Price",
  news: "News",
  sec_edgar: "SEC filings",
  federal_register: "Federal Register",
  nhtsa: "NHTSA recalls",
  fred: "FRED",
  congress: "Congress.gov",
  bls: "BLS",
};

export function signalLabel(source: string): string {
  return SOURCE_LABELS[source] ?? source.replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase());
}

/** "5m" → "every 5 min", "1h" → "every hour". */
export function pollLabel(poll: string): string {
  const m = /^(\d+)\s*([smhd])$/i.exec(poll.trim());
  if (!m) return poll;
  const n = Number(m[1]);
  const unit = m[2].toLowerCase();
  const names: Record<string, [string, string]> = { s: ["second", "sec"], m: ["minute", "min"], h: ["hour", "h"], d: ["day", "days"] };
  if (unit === "m" && n % 60 === 0) return n === 60 ? "every hour" : `every ${n / 60} h`;
  if (n === 1) return `every ${names[unit][0]}`;
  return `every ${n} ${names[unit][1]}`;
}

export function signalSummary(s: SignalSpec): string {
  return `${signalLabel(s.source)}, ${pollLabel(s.poll)}`;
}

export function deliveryLabel(a: Pick<Alert, "channel" | "delivery_status">): string {
  if (a.channel === "call") {
    switch (a.delivery_status) {
      case "pending":
        return "Calling";
      case "sent":
        return "Call placed";
      case "delivered":
        return "Call answered";
      case "retrying":
        return "Retrying call";
      case "failed":
        return "Call missed";
    }
  }
  switch (a.delivery_status) {
    case "pending":
      return "Sending text";
    case "sent":
      return "Text sent";
    case "delivered":
      return "Text delivered";
    case "retrying":
      return "Retrying text";
    case "failed":
      return "Text failed";
  }
  return a.delivery_status;
}
