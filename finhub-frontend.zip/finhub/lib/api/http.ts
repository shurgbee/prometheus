import { parseEventStream } from "./sse";
import type { FinanceApi } from "./interface";
import type {
  Alert,
  ChatEvent,
  ChatRequest,
  Evaluation,
  HistoryRange,
  Holding,
  HoldingInput,
  ImportResult,
  InjectSignalRequest,
  InjectSignalResponse,
  NetWorthHistory,
  Portfolio,
  Report,
  ReportSearchResponse,
  ResearchJob,
  ResumeRequest,
  Trigger,
  TriggerPatch,
} from "./types";

// Empty base = same origin; next.config.js proxies /api/* to BACKEND_URL.
const BASE = (process.env.NEXT_PUBLIC_API_BASE_URL || "").replace(/\/+$/, "");
const TOKEN = process.env.NEXT_PUBLIC_API_TOKEN || "";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

function headers(extra?: Record<string, string>): Record<string, string> {
  const h: Record<string, string> = { Accept: "application/json", ...extra };
  if (TOKEN) h.Authorization = `Bearer ${TOKEN}`;
  return h;
}

async function errorFrom(res: Response): Promise<ApiError> {
  let message = `${res.status} ${res.statusText}`.trim();
  try {
    const body = await res.json();
    // FastAPI puts errors in `detail` (string or validation array).
    if (typeof body?.detail === "string") message = body.detail;
    else if (Array.isArray(body?.detail)) message = body.detail.map((d: { msg?: string }) => d.msg).join("; ");
    else if (typeof body?.message === "string") message = body.message;
  } catch {
    // Non-JSON 5xx usually means the Next.js proxy couldn't reach the backend.
    if (res.status >= 500) message = `The backend isn't responding (HTTP ${res.status}). Check that it's running at BACKEND_URL`;
  }
  return new ApiError(res.status, message);
}

async function send(url: string, init: RequestInit): Promise<Response> {
  try {
    return await fetch(url, init);
  } catch (e) {
    if ((e as { name?: string })?.name === "AbortError") throw e;
    throw new ApiError(0, "Can't reach the backend. Check that it's running and the URL is right");
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const isForm = typeof FormData !== "undefined" && init.body instanceof FormData;
  const res = await send(`${BASE}${path}`, {
    ...init,
    headers: headers(init.body && !isForm ? { "Content-Type": "application/json" } : undefined),
    cache: "no-store",
  });
  if (!res.ok) throw await errorFrom(res);
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  return (text ? JSON.parse(text) : undefined) as T;
}

async function* stream(path: string, body: unknown, signal?: AbortSignal): AsyncGenerator<ChatEvent> {
  const res = await send(`${BASE}${path}`, {
    method: "POST",
    headers: headers({ "Content-Type": "application/json", Accept: "text/event-stream" }),
    body: JSON.stringify(body),
    signal,
    cache: "no-store",
  });
  if (!res.ok) throw await errorFrom(res);
  if (!res.body) throw new ApiError(500, "The chat response had no body to stream.");
  yield* parseEventStream(res.body);
}

const enc = encodeURIComponent;

export const httpApi: FinanceApi = {
  getPortfolio: () => request<Portfolio>("/api/portfolio"),
  getNetWorthHistory: (range: HistoryRange) => request<NetWorthHistory>(`/api/networth/history?range=${enc(range)}`),

  createHolding: (input: HoldingInput) =>
    request<Holding>("/api/holdings", { method: "POST", body: JSON.stringify(input) }),
  updateHolding: (id: string, patch: Partial<HoldingInput>) =>
    request<Holding>(`/api/holdings/${enc(id)}`, { method: "PATCH", body: JSON.stringify(patch) }),
  deleteHolding: (id: string) => request<void>(`/api/holdings/${enc(id)}`, { method: "DELETE" }),
  importHoldings: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<ImportResult>("/api/holdings/import", { method: "POST", body: form });
  },

  listTriggers: () => request<Trigger[]>("/api/triggers"),
  updateTrigger: (id: string, patch: TriggerPatch) =>
    request<Trigger>(`/api/triggers/${enc(id)}`, { method: "PATCH", body: JSON.stringify(patch) }),
  deleteTrigger: (id: string) => request<void>(`/api/triggers/${enc(id)}`, { method: "DELETE" }),
  getEvaluations: (id: string, since: string) =>
    request<Evaluation[]>(`/api/triggers/${enc(id)}/evaluations?since=${enc(since)}`),

  listAlerts: (status: "open" | "all") => request<Alert[]>(`/api/alerts?status=${status}`),
  ackAlert: (id: string) => request<Alert>(`/api/alerts/${enc(id)}/ack`, { method: "POST" }),

  searchReports: (q?: string) =>
    request<ReportSearchResponse>(q && q.trim() ? `/api/reports?q=${enc(q.trim())}` : "/api/reports"),
  getReport: (id: string) => request<Report>(`/api/reports/${enc(id)}`),
  startResearch: (topic: string) =>
    request<ResearchJob>("/api/research", { method: "POST", body: JSON.stringify({ topic }) }),
  getResearchJob: (jobId: string) => request<ResearchJob>(`/api/research/${enc(jobId)}`),

  streamChat: (req: ChatRequest, signal?: AbortSignal) => stream("/api/chat", req, signal),
  resumeChat: (threadId: string, req: ResumeRequest, signal?: AbortSignal) =>
    stream(`/api/chat/${enc(threadId)}/resume`, req, signal),

  injectSignal: (req: InjectSignalRequest) =>
    request<InjectSignalResponse>("/api/dev/inject-signal", { method: "POST", body: JSON.stringify(req) }),
};
