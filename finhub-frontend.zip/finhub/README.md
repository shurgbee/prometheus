# Finance Hub frontend

The dashboard and advisor chat for the Personal Finance Hub hackathon MVP. Built with Next.js 14,
TypeScript, Tailwind and Recharts. It runs on simulated data out of the box, so you can work on it
(and record the demo) before the backend is ready.

## Run it

Requires Node 18.17 or newer.

```bash
npm install
cp .env.example .env.local
npm run dev            # http://localhost:3000
```

With the default `.env.local` everything is simulated in the browser ("Demo data" shows in the top
bar). A full page reload resets the simulated data.

## Connecting the backend

1. In `.env.local` set:

   ```bash
   NEXT_PUBLIC_USE_MOCKS=false
   BACKEND_URL=http://localhost:8000   # wherever FastAPI runs
   ```

2. Restart `npm run dev`. These values are read at startup (and baked in by `npm run build`), so a
   restart or rebuild is needed after any change.

The browser calls `/api/...` on the frontend's own origin and Next.js forwards it to `BACKEND_URL`,
including the chat stream, so FastAPI needs no CORS setup. The backend must implement the routes and
shapes in **[API_CONTRACT.md](API_CONTRACT.md)**.

To test the frontend in real mode without the backend, run the reference stub and point at it:

```bash
PORT=8010 node scripts/contract-stub.mjs
# .env.local: NEXT_PUBLIC_USE_MOCKS=false, BACKEND_URL=http://localhost:8010
```

## What's where

| Path | What it is |
| --- | --- |
| `app/page.tsx` | Overview: net worth, allocation, history, Watching (triggers), alerts, reports, holdings, CD ladder |
| `app/reports` | Report search, "Start a report", and the report page |
| `app/holdings` | Add, edit, delete holdings and CSV import |
| `components/chat` | Advisor chat: streaming replies, tool steps, trigger approval cards, research cards |
| `components/DemoDrawer.tsx` | "Demo events": sends a normal or critical event through a trigger |
| `lib/api/types.ts` | The API contract as TypeScript types |
| `lib/api/http.ts` | Real client, including the SSE parser in `lib/api/sse.ts` |
| `lib/api/mock/` | The in-browser mock backend and its seed data |
| `scripts/contract-stub.mjs` | Reference server that speaks the contract |

## Recording the demo

1. Open the overview. Ask the advisor "I see a lot of Teslas on the road, why?"
2. Approve the triggers you want (you can rename a trigger or turn calls off first).
3. Open **Demo events**. Pick **Minor recall (normal)** and send it, then **SEC action and 8% drop
   (critical)**. With the real backend, the phone gets a text and then a call. The alert appears in
   **Alerts** within 5 seconds; open **Why** for the severity breakdown.
4. Ask "Write a report on EV subsidies", open it from the chat, then search "EV subsidies" under Reports.

The drawer picks a trigger that is allowed to call (a Tesla one first). A trigger that can't call
caps critical events at normal, as the spec's hard rules require.

## Scripts

| Command | Does |
| --- | --- |
| `npm run dev` | Development server |
| `npm run build` then `npm start` | Production build and server |
| `npm run lint` | ESLint |
| `npm run typecheck` | TypeScript check |
