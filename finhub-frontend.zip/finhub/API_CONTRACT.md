# Finance Hub API contract

This is what the frontend expects from the FastAPI backend. The TypeScript source of truth is
[`lib/api/types.ts`](lib/api/types.ts). If the backend has to differ, change both files together.

`scripts/contract-stub.mjs` is a tiny server that returns these shapes (including the chat stream).
Run it to see real example responses: `PORT=8010 node scripts/contract-stub.mjs`.

## Conventions

| Rule | Example |
| --- | --- |
| Money is a plain USD number | `248310.42` (not `"$248,310.42"`, not cents) |
| Percentages and rates are **fractions** | `0.0123` = 1.23%, APY `0.046` = 4.6% |
| Timestamps are ISO 8601 with a timezone | `"2026-11-07T19:30:00Z"` |
| Calendar dates are `YYYY-MM-DD` | `"2027-03-02"` |
| IDs are strings | `"t-8f2c"` |
| Nullable fields are always present, set to `null` | `"ticker": null` |
| Errors use FastAPI's shape | `{"detail": "Trigger not found"}` with a 4xx/5xx status |
| `204 No Content` for deletes | empty body |

Auth: if `NEXT_PUBLIC_API_TOKEN` is set, every request carries `Authorization: Bearer <token>`.

The frontend calls `/api/...` on its own origin, and Next.js proxies to `BACKEND_URL`, so **no CORS
setup is needed**. If you set `NEXT_PUBLIC_API_BASE_URL` instead (direct calls), add FastAPI's
`CORSMiddleware` allowing the frontend origin, the `Authorization` header, and `POST/PATCH/DELETE`.

## Routes

| Method | Path | Request | Response |
| --- | --- | --- | --- |
| GET | `/api/portfolio` | | `Portfolio` |
| GET | `/api/networth/history?range=1M\|3M\|1Y\|ALL` | | `NetWorthHistory` |
| POST | `/api/holdings` | `HoldingInput` | `Holding` (201 or 200) |
| PATCH | `/api/holdings/{id}` | partial `HoldingInput` | `Holding` |
| DELETE | `/api/holdings/{id}` | | 204 |
| POST | `/api/holdings/import` | `multipart/form-data`, field `file` (CSV) | `ImportResult` |
| GET | `/api/triggers` | | `Trigger[]` (newest first) |
| PATCH | `/api/triggers/{id}` | `TriggerPatch`, e.g. `{"status":"paused"}` | `Trigger` |
| DELETE | `/api/triggers/{id}` | | 204 |
| GET | `/api/triggers/{id}/evaluations?since=<ISO>` | | `Evaluation[]` (oldest first) |
| GET | `/api/alerts?status=open\|all` | | `Alert[]` (newest first). `open` = not acknowledged |
| POST | `/api/alerts/{id}/ack` | | `Alert` (with `acked_at` set) |
| GET | `/api/reports` or `/api/reports?q=<text>` | | `ReportSearchResponse` |
| GET | `/api/reports/{id}` | | `Report` (404 if missing) |
| POST | `/api/research` | `{"topic": "..."}` | `ResearchJob` (200 or 202) |
| GET | `/api/research/{job_id}` | | `ResearchJob` |
| POST | `/api/chat` | `ChatRequest` | **SSE stream** of `ChatEvent` |
| POST | `/api/chat/{thread_id}/resume` | `ResumeRequest` | **SSE stream** of `ChatEvent` |
| POST | `/api/dev/inject-signal` | `InjectSignalRequest` | `InjectSignalResponse` |

`GET /api/events` from the spec is **not used**: the MVP polls instead (alerts every 5 s,
triggers and evaluations every 30 s, portfolio every 60 s while the market is open).

## Shapes

### Holding

```json
{
  "id": "h-tsla",
  "asset_class": "stock",          // "cash" | "cd" | "stock"
  "name": "Tesla",
  "ticker": "TSLA",                // stocks only, else null
  "quantity": 40,                  // stocks only, else null
  "cost_basis": 205.0,             // stocks only: average cost PER SHARE
  "principal": null,               // cash: balance; CD: amount deposited; stocks: null
  "apy": null,                     // CDs (and optionally cash), fraction
  "start_date": null,              // CDs only, YYYY-MM-DD
  "maturity_date": null            // CDs only, YYYY-MM-DD
}
```

`HoldingInput` is the same without `id`. CSV import uses the same column names:
`asset_class,name,ticker,quantity,cost_basis,principal,apy,start_date,maturity_date`.

`ImportResult`: `{"imported": 3, "errors": [{"row": 4, "message": "Stocks need a ticker."}]}`
(`row` counts the header as row 1).

### Portfolio

```json
{
  "as_of": "2026-11-07T20:00:00Z",
  "market_open": false,
  "total": 246266.06,
  "day_change": 509.12,
  "day_change_pct": 0.0021,
  "allocation": { "cash": 38550, "cd": 41010.06, "stocks": 166706 },
  "holdings": [ /* ValuedHolding[] */ ]
}
```

`ValuedHolding` = `Holding` plus:

| Field | Meaning |
| --- | --- |
| `price` | latest share price (stocks), else `null` |
| `value` | stock: quantity × price; cash: principal; CD: accrued value `P × (1 + APY/365)^days` (stop at maturity) |
| `day_change`, `day_change_pct` | vs previous close; `null` for cash and CDs |
| `gain`, `gain_pct` | stock: value − quantity × cost_basis; CD: value − principal; cash: `null` |
| `weight` | value / total, 0..1 |

### NetWorthHistory

`{"range": "3M", "points": [{"ts": "2026-08-10", "total": 236100, "cash": 38000, "cd": 40500, "stocks": 157600}]}`,
one point per day, oldest first.

### TriggerSpec and Trigger

`TriggerSpec` is exactly the spec's JSON:

```json
{
  "name": "Tesla – leadership & legal",
  "entity": "Tesla",
  "tickers": ["TSLA"],
  "hypothesis": "Investigations or legal action involving Tesla or Elon Musk move TSLA",
  "signals": [
    { "source": "news", "query": "Tesla OR Musk investigation", "detector": "text_event", "poll": "5m" },
    { "source": "price", "query": "TSLA", "detector": "daily_change", "params": { "threshold": 0.03 }, "poll": "1m" }
  ],
  "critical_capable": true,
  "cooldown": { "normal": "6h", "critical": "1h" }
}
```

`source` values the UI labels nicely: `price`, `news`, `sec_edgar`, `federal_register`, `nhtsa`, `fred`
(others display as-is). `poll` is `<n>s|m|h|d`.

`Trigger` = `TriggerSpec` plus `id`, `status` (`"active" | "paused"`), `pinned`, `created_at`,
`last_checked_at`, `last_level` (`"ok" | "normal" | "critical" | null`), `last_severity` (0–100 or `null`).

### Evaluation

```json
{ "ts": "2026-11-07T19:59:00Z", "severity": 87, "level": "critical",
  "magnitude": 0.9, "exposure": 0.41, "credibility": 1, "urgency": 1, "adjustment": 5 }
```

`level` follows the spec's bands: below 40 `ok`, 40–74 `normal`, 75+ `critical` (after the hard
rules, so a capped evaluation can have severity 80 and level `normal`).

### Alert

```json
{
  "id": "a-91",
  "trigger_id": "t-8f2c",
  "trigger_name": "Tesla – leadership & legal",
  "ts": "2026-11-07T19:59:02Z",
  "level": "critical",
  "severity": 87,
  "summary": "SEC opens an investigation into the CEO's disclosures. TSLA is down 8.0%.",
  "rationale": "Large, credible event with immediate price impact.",
  "breakdown": { "magnitude": 0.9, "exposure": 0.41, "credibility": 1, "urgency": 1, "adjustment": 5 },
  "evidence": [{ "title": "SEC press release", "url": "https://...", "publisher": "SEC" }],
  "channel": "call",
  "delivery_status": "delivered",
  "attempts": 1,
  "acked_at": null
}
```

| `channel` | `delivery_status` shown as |
| --- | --- |
| `text` | pending: "Sending text", sent: "Text sent", delivered: "Text delivered", retrying: "Retrying text", failed: "Text failed" |
| `call` | pending: "Calling", sent: "Call placed", delivered: "Call answered", retrying: "Retrying call", failed: "Call missed" |

### Reports and research

`ReportSummary`: `{ id, title, topic, summary, tickers[], created_at }`

`Report` = summary + `body_md` (Markdown, GitHub tables allowed), `sources[]`
(`{ url, publisher, published_at, excerpt }`, each nullable except `url`), and `similar[]` (`ReportSummary`, up to 3).

`ReportSearchResponse`:

```json
{
  "results": [{ "report": { /* ReportSummary */ }, "passage": "best-matching passage", "score": 0.82 }],
  "similar": [ /* ReportSummary[], excluding anything in results */ ]
}
```

Without `q`: every report newest first, `passage` and `score` `null`, `similar` `[]`.

`ResearchJob`: `{ job_id, topic, status: "queued"|"running"|"done"|"failed", report_id, error }`.
The UI polls `GET /api/research/{job_id}` every 3 s until `done` (then links to `report_id`) or `failed` (shows `error`).

## Chat stream (SSE)

`POST /api/chat` with `{"thread_id": null, "message": "I see a lot of Teslas on the road, why?"}`
returns `Content-Type: text/event-stream`. Each frame is an `event:` line naming the type, a `data:`
line with JSON, and a blank line. Send frames as they happen (don't buffer); comments (`: ...`) are ignored.

```
event: thread
data: {"thread_id": "th-12"}

event: tool
data: {"id": "t1", "name": "get_quote", "status": "running", "label": "Getting the TSLA quote"}

event: tool
data: {"id": "t1", "name": "get_quote", "status": "done"}

event: token
data: {"text": "Teslas are common because "}

event: sources
data: {"items": [{"title": "...", "url": "https://...", "publisher": "NYT"}]}

event: proposals
data: {"proposals": [{"proposal_id": "p1", "spec": { /* TriggerSpec */ }}]}

event: done
data: {}
```

| Event | Data | UI behaviour |
| --- | --- | --- |
| `thread` | `{thread_id}` | Send first when the request had `thread_id: null`. The UI sends it back on later messages. |
| `token` | `{text}` | Appended to the reply. Markdown is rendered. |
| `tool` | `{id, name, status, label?}` | A step list ("Reading your portfolio"). Same `id` updates the step. `status`: `running`, `done`, `error`. |
| `sources` | `{items: [{title, url, publisher?}]}` | Source chips under the reply. |
| `proposals` | `{proposals: [{proposal_id, spec}]}` | Approval cards. The UI blocks new messages until the user decides. End the stream after this (LangGraph `interrupt`). |
| `triggers_created` | `{triggers: Trigger[]}` | "Now watching" card; the Watching list refreshes. Send from the resume stream. |
| `research` | `{job_id, topic}` | A research card that polls the job. |
| `error` | `{message}` | Shown inline in the reply. |
| `done` | `{}` | End of the reply. Close the stream. |

### Resume after approval

`POST /api/chat/{thread_id}/resume`:

```json
{ "decisions": [
  { "proposal_id": "p1", "action": "approve" },
  { "proposal_id": "p2", "action": "approve", "spec": { /* edited TriggerSpec: name and/or critical_capable changed */ } },
  { "proposal_id": "p3", "action": "reject" }
] }
```

Every proposal from the last `proposals` event gets exactly one decision. When `spec` is present,
create the trigger from it instead of the original. The response is another SSE stream, typically
`tool` events for `create_trigger`, then `triggers_created`, then `token`s, then `done`.

## Demo injection

`POST /api/dev/inject-signal`:

```json
{ "trigger_id": "t-8f2c", "source": "sec_edgar", "title": "SEC opens an investigation into the CEO's disclosures",
  "url": null, "magnitude": 0.9, "price_change_pct": -0.08 }
```

`magnitude` and `price_change_pct` are optional (`null` = let the detectors decide). Response:
`{"evaluation": Evaluation, "alert": Alert | null}`. `alert` is `null` when the score stayed under 40
or the cooldown suppressed it. The event should run the same path as a real signal: score, triage, `/notify`.
