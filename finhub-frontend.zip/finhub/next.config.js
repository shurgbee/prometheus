/** @type {import('next').NextConfig} */

// When BACKEND_URL is set (e.g. http://localhost:8000), every /api/* request
// from the browser is proxied to the FastAPI backend, so no CORS setup is needed.
// See README.md "Connecting the backend".
const backendUrl = (process.env.BACKEND_URL || "").replace(/\/+$/, "");

const nextConfig = {
  reactStrictMode: true,
  async rewrites() {
    if (!backendUrl) return [];
    return [
      {
        source: "/api/:path*",
        destination: `${backendUrl}/api/:path*`,
      },
    ];
  },
};

module.exports = nextConfig;
